# YOLOv5 > 2025-06-04 1:17pm
https://universe.roboflow.com/jeet-bsxze/yolov5-5iknt

Provided by a Roboflow user
License: CC BY 4.0

